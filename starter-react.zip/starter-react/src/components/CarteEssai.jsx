export default function CarteEssai({ titre, duree }) {
  // Exercice 1 : la même carte doit afficher les valeurs reçues du parent.
  return (
    <div>
      <p>Titre à remplacer</p>
      <p>Durée à remplacer</p>
    </div>
  );
}
