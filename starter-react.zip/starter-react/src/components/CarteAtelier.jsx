export default function CarteAtelier({ atelier }) {
  return (
    <div className="carte">
      <img className="affiche" src={`/affiches/${atelier.id}.png`} alt="" width="720" height="360" />
      <div className="carte-texte">
        <p className="technique">{atelier.technique}</p>
        <h3>{atelier.titre}</h3>
        <p className="horaire">{atelier.heure} · {atelier.duree}</p>
        <details>
          <summary>Au programme</summary>
          <p>{atelier.detail}</p>
        </details>
      </div>
    </div>
  );
}
