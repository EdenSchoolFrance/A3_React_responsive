import CarteAtelier from "./components/CarteAtelier.jsx";
import { ateliers } from "./data/ateliers.js";
import "./styles/programme.css";

export default function App() {
  return (
    <div className="cadre">
      <header className="entete">
        <span className="marque">Pli Papier<span aria-hidden="true">.</span></span>
        <div className="navigation">
          <a href="#programme">Les ateliers</a>
          <a href="#infos">Infos pratiques</a>
        </div>
      </header>
      <main>
        <div className="intro">
          <p className="etiquette">Festival de l’estampe</p>
          <h1>Les mains dans l’encre.</h1>
          <p>Six ateliers pour graver, imprimer et plier le papier. Choisis une technique et découvre le programme.</p>
        </div>
        <section id="programme" aria-labelledby="titre-programme">
          <h2 id="titre-programme">Les ateliers</h2>
          <div className="grille">
            {ateliers.map((atelier) => <CarteAtelier key={atelier.id} atelier={atelier} />)}
          </div>
        </section>
      </main>
      <footer id="infos">
        <h2>Infos pratiques</h2>
        <p>À la Maison du papier · Entrée libre · Matériel fourni sur place.</p>
      </footer>
    </div>
  );
}
