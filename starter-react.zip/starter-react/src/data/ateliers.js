export const ateliers = [
  { id: "vague", titre: "Graver la vague", technique: "Linogravure", heure: "10 h 00", duree: "45 min", detail: "Grave une vague dans une plaque souple, encre-la et repars avec ton tirage." },
  { id: "orbite", titre: "Imprimer en orbite", technique: "Sérigraphie", heure: "10 h 45", duree: "50 min", detail: "Superpose deux encres pour composer une affiche de planètes." },
  { id: "lettre", titre: "Jouer avec la lettre", technique: "Typographie", heure: "11 h 30", duree: "40 min", detail: "Compose un mot en caractères de bois, puis imprime-le à la presse." },
  { id: "jardin", titre: "Composer un herbier", technique: "Monotype", heure: "13 h 30", duree: "45 min", detail: "Dispose des feuilles sur une plaque encrée pour obtenir une empreinte unique." },
  { id: "plis", titre: "Plier un fanzine", technique: "Microédition", heure: "14 h 30", duree: "50 min", detail: "Transforme une feuille en livret de huit pages et illustre sa couverture." },
  { id: "trame", titre: "Croiser les trames", technique: "Risographie", heure: "15 h 30", duree: "45 min", detail: "Décale deux trames colorées et observe les motifs qui apparaissent." }
];
