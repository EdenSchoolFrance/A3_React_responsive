import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import Labo from "./Labo.jsx";
import "./styles/base.css";

const isLab = new URLSearchParams(window.location.search).get("vue") === "labo";
createRoot(document.getElementById("root")).render(isLab ? <Labo /> : <App />);
