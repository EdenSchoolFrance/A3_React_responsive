import CarteEssai from "./components/CarteEssai.jsx";
import "./styles/labo.css";

export default function Labo() {
  return (
    <main className="labo">
      <a className="retour" href="./">Retour au festival</a>
      <p className="etiquette">Pli Papier</p>
      <h1>Le labo CSS</h1>
      <section id="cartes">
        <h2>1. Une carte en JSX</h2>
        <div className="cartes-essai">
          <CarteEssai titre="Encrer une plaque" duree="20 min" />
          <CarteEssai titre="Plier un livret" duree="30 min" />
        </div>
      </section>
      <section id="liens">
        <h2>2. Des liens qui reviennent à la ligne</h2>
        <div className="cadre-essai">
          <nav className="liens-essai" aria-label="Exercices">
            <a href="#cartes">Cartes en JSX</a>
            <a href="#liens">Liens flexibles</a>
            <a href="#formats">Grille de formats</a>
          </nav>
        </div>
      </section>
      <section id="formats">
        <h2>3. Une grille de formats</h2>
        <div className="grille-essai">
          {["Portrait", "Paysage", "Carré", "Panoramique"].map((format) => (
            <div className="format" key={format}>{format}</div>
          ))}
        </div>
      </section>
    </main>
  );
}
