# Pli Papier · projet de départ

## Démarrer
Installe Node.js 22.12 ou plus récent (série 22 ou 24 conseillée). Ouvre un terminal dans le dossier qui contient ce README et package.json, puis lance :

```sh
npm ci
npm run dev
```

Ouvre l’adresse **Local** affichée par Vite. L’installation initiale des dépendances nécessite Internet. Si le port proposé est déjà occupé, utilise celui indiqué dans le terminal. Pour arrêter le serveur, tape Ctrl+C.

## Où travailler
- **Exercices** : ajoute `/?vue=labo` après le port (exemple : `http://localhost:5173/?vue=labo`). Modifie `src/components/CarteEssai.jsx` et `src/styles/labo.css`.
- **TP** : ouvre la racine du site (exemple : `http://localhost:5173/`). Modifie `src/App.jsx`, `src/components/CarteAtelier.jsx` et `src/styles/programme.css`. La largeur de bureau est volontairement fixe au départ.
- Les six ateliers et les illustrations sont fournis. La feuille `base.css` contient les couleurs, la typographie et les finitions communes.

## Tester et rendre
Ouvre les outils de développement, active le mode appareil et saisis les largeurs du sujet en pixels CSS. Redimensionne aussi entre ces valeurs. Le contenu caché de chaque atelier s’ouvre avec « Au programme ».

Avant de rendre le projet, exécute `npm run build`. Pour voir la version construite, lance `npm run preview` et ouvre l’adresse indiquée. Archive le code, les affiches, le fichier de verrouillage et les preuves demandées, en excluant `node_modules` et `dist`.
